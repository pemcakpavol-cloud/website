document.addEventListener("DOMContentLoaded", function () {
    const scrollButton = document.querySelector(".scroll-to-top");

    window.addEventListener("scroll", function () {
        if (window.scrollY > 200) {
            scrollButton.classList.add("show");
        } else {
            scrollButton.classList.remove("show");
        }
    });
});